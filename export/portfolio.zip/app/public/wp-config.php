<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'KpVSlWSPezI4lEMzZIhR3BKK07lxU1GTYfEUc4ol2sCKt7IZ5cKtSCf5mVfrxavx1xIBcS1Zhg5R/vc6GsOTlA==');
define('SECURE_AUTH_KEY',  'WOx9Y7Yll/xy5ETqYGa1xso/nOMZenUxTEbADLXMsa1CG1RdonxrDuo/DdCKX3u7eivXNI8BkwnO4rz3BtH6tA==');
define('LOGGED_IN_KEY',    'I2kgdP8fjqkSAqI1W+o4ACpSRde1VNddWjPhfFHkVSg8AWQTO5qedD8KRGfy/C2qNd/cCXwIU4mq3Xg5KezkcQ==');
define('NONCE_KEY',        'tWPmtahkXWaHasVWa2Hn7SAWowcPq4fdcFlDIUL3xH4KW+khq6qxZLeI8lrqDNnxEax3z0ll1BtjCWyef10rSw==');
define('AUTH_SALT',        'Oxg0rlCHk25Yo5JidqZY/bmwVA8yIRSbWwTbEfRg/FJK8W4eR2ByO1B1JnPPituJvF1Brou3HldttaWlkni/Ow==');
define('SECURE_AUTH_SALT', 'L4BdCtQDcroIAjWaq06tC1g+wWGmAoRRND7Bl/e4FTq2pHABzmbST7gpg/Shtha1tetLC6tZWQqplegqqvDblw==');
define('LOGGED_IN_SALT',   'fYnxZggVsuqQAtiJFYTEeg/HGvidUR+sQOSB2LpIRNAnKYw70HcD/KIdDRiohpNeXLwRmi+jCws7pDvnmJ5ydw==');
define('NONCE_SALT',       'vJBHyL8sFWt2OFvLJq/Dd2S8i4ajwi26COipNEv5VJDajdbAG1qaJorAfun2bqW/mzI9/pHgx/iu3peey/0UcQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
